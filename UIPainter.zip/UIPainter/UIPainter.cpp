// UIPainter.cpp : ����Ӧ�ó��������Ϊ��
//

#include "stdafx.h"
#include "UIPainter.h"
#include "MainFrm.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CUIPainterApp

BEGIN_MESSAGE_MAP(CUIPainterApp, CWinApp)

END_MESSAGE_MAP()


CUIPainterApp::CUIPainterApp()
{
	// TODO: �ڴ˴����ӹ�����룬
	// ��������Ҫ�ĳ�ʼ�������� InitInstance ��
}

void Test1(int x,int y)
{
	//MessageBox(g_pWnd->m_hWnd,"�����߿�ť����Ϣ��Ӧ","��ʾ",0);
}

void Test2(int x,int y)
{
	//MessageBox(g_pWnd->m_hWnd,"�����زİ�ť����Ϣ��Ӧ","��ʾ",0);
}

// Ψһ��һ�� CUIPainterApp ����

CUIPainterApp theApp;

SUIManager* g_UI;

BOOL CUIPainterApp::InitInstance()
{
	INITCOMMONCONTROLSEX InitCtrls;
	InitCtrls.dwSize = sizeof(InitCtrls);
	InitCtrls.dwICC = ICC_WIN95_CLASSES;
	InitCommonControlsEx(&InitCtrls);
	CWinApp::InitInstance();
	if (!AfxOleInit())
	{
		AfxMessageBox(IDP_OLE_INIT_FAILED);
		return FALSE;
	}
	AfxEnableControlContainer();
	SetRegistryKey(_T("Ӧ�ó��������ɵı���Ӧ�ó���"));
	CMainFrame* pFrame = new CMainFrame;
	if (!pFrame)
		return FALSE;
	m_pMainWnd = pFrame;
	pFrame->LoadFrame(IDR_MAINFRAME,
		WS_OVERLAPPEDWINDOW | FWS_ADDTOTITLE, NULL,
		NULL);

///////��ʼ������ȫ����/////////
	g_pWnd=(CMainFrame*)AfxGetMainWnd();
	g_pView=(CChildView*)&g_pWnd->m_wndView;
	g_BufDC.CreateCompatibleDC(g_pView->GetDC());
	g_BufBMP.CreateCompatibleBitmap(g_pView->GetDC(),g_Width,g_Height);
	g_BufDC.SelectObject(&g_BufBMP);
	g_BufDC.SetBkMode(TRANSPARENT);
	//���ؿؼ�

	SUIInitialize();//��ʼ��SUI
	SummerUI::AddImage(L"Res/Image/module.png");
	SummerUI::AddImage(L"Res/Image/btnX.png");
	SummerUI::AddImage(L"Res/Image/box.png");
	SummerUI::AddImage(L"Res/Image/btn_sys_close.png");
	SummerUI::AddImage(L"Res/Image/btn_sys_maximize.png");
	SummerUI::AddImage(L"Res/Image/btn_sys_minimize.png");
	SummerUI::AddImage(L"Res/Image/orange.png");
	//SummerUI::SetFont(L"����",13);
	g_UI=new SUIManager(g_pWnd->m_hWnd,1000,700);
	SWindow* window=new SWindow(100,150,1000,700);
	//window->m_Image=2;
	window->m_CloseButtonImage=3;
	window->m_CloseButtonWidth=43;
	window->m_MaxButtonImage=4;
	window->m_MaxButtonWidth=30;
	window->m_MiniButtonImage=5;
	window->m_MiniButtonWidth=32;
	g_UI->Add(window);
	SImage* image=new SImage(0,0,49,51);
	image->m_Image=6;
	g_UI->Add(image);
	SImageButton* button=new SImageButton(20,300,100,30);
	button->m_Image=1;
	button->m_FrameWidth=80;
	button->m_FrameHeight=26;
	button->m_Text=L"�زİ�ť";
	button->m_ImageMode=SUI_IMAGEMODE_REPEAT;
	button->m_OnLDown=Test2;
	g_UI->Add(button);
    SCardGrid* grid=new SCardGrid(20,50,2,5,60,60);
	grid->m_FrameW=48;
	grid->m_nCard=9;
	grid->m_Image=0;
	//grid->m_BackImage=2;
	//grid->m_HotImage=2;
	g_UI->Add(grid);	
	SRectButton* rbutton=new SRectButton(200,300,100,30);
	rbutton->m_Text=L"�߿�ť";
	rbutton->m_OnLDown=Test1;
	g_UI->Add(rbutton);
	SBoard*   board=new SBoard(500,80,420,433);
	board->m_Image=2;
	g_UI->Add(board);
	//board->AddChild(button);
	g_UI->EnableAlpha(true,200);

	pFrame->ShowWindow(SW_SHOW);
	pFrame->UpdateWindow();
	return TRUE;
}


// CUIPainterApp ��Ϣ��������




// ����Ӧ�ó��򡰹��ڡ��˵���� CAboutDlg �Ի���

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// �Ի�������
	enum { IDD = IDD_ABOUTBOX };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

// ʵ��
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


