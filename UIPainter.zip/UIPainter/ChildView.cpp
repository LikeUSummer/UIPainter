#include "stdafx.h"
#include "ChildView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif
extern SUIManager* g_UI;

CChildView::CChildView()
{

}


CChildView::~CChildView()
{
	SUIExit();//ж��SUI
}

BEGIN_MESSAGE_MAP(CChildView, CWnd)
	ON_WM_PAINT()
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_CHAR()
	ON_WM_SIZE()
	ON_WM_RBUTTONDOWN()
	ON_WM_ERASEBKGND()
	ON_WM_LBUTTONUP()
END_MESSAGE_MAP()


BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs) 
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	//cs.dwExStyle |= WS_EX_CLIENTEDGE;
	//cs.style &=(~(WS_CAPTION | WS_BORDER |WS_EX_CLIENTEDGE));
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS, 
		::LoadCursor(NULL, IDC_ARROW), reinterpret_cast<HBRUSH>(COLOR_WINDOW+1), NULL);
	return TRUE;
}

void CChildView::OnPaint() 
{
    //g_UI->OnPaint();
}

BOOL CChildView::OnEraseBkgnd(CDC* pDC)
{
	return true;
}

void CChildView::OnLButtonDown(UINT nFlags, CPoint point)
{
    //g_UI->OnLDown(point.x,point.y);
	CWnd::OnLButtonDown(nFlags, point);
}

void CChildView::OnMouseMove(UINT nFlags, CPoint point)
{ 
    //g_UI->OnMouseMove(point.x,point.y);
	CWnd::OnMouseMove(nFlags, point);
}

void CChildView::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	CWnd::OnChar(nChar, nRepCnt, nFlags);
}

void CChildView::OnRButtonDown(UINT nFlags, CPoint point)
{
    //g_UI->OnRDown(point.x,point.y);
	CWnd::OnRButtonDown(nFlags, point);
}

void CChildView::OnSize(UINT nType, int cx, int cy)
{
	CWnd::OnSize(nType, cx, cy);
	//if(g_UI)
      //g_UI->OnSize(cx,cy);
}
void CChildView::OnLButtonUp(UINT nFlags, CPoint point)
{
   // g_UI->OnLUp(point.x,point.y);
	CWnd::OnLButtonUp(nFlags, point);
}
