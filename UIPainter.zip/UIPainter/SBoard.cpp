#include "stdafx.h"
#include "SBoard.h"
/*
SBoard��˵��
Board�ؼ�������һ��ƽ�壬���ƶ����ɴ��ظ����ӿؼ�
*/


SBoard::SBoard(int x1,int y1,int w,int h):SummerUI(x1,y1,w,h)
{
	m_MouseDown=false;
	m_nSpace=0;
	m_nChild=0;
	m_Children=NULL;
}

void SBoard::AddChild(SummerUI* pUI)
{
	if(m_nChild>m_nSpace-1)
	{
		if(SUIRealloc((LPVOID*)&m_Children,m_nSpace+16,sizeof(SUIChild)))
		    m_nSpace+=16;
		else
		    return;
	}
	m_Children[m_nChild].pChild=pUI;
	m_Children[m_nChild].rx=pUI->m_X1; //��ʼ��X1,Y1��������꣬����һ�����оͻᱻ�ı��ȫ������
	m_Children[m_nChild].ry=pUI->m_Y1; //�������ȴ洢����Ը��ؼ������꣬Ȼ����Ϊ����任����
	pUI->m_pWinDC=m_pWinDC;
	pUI->m_pBufDC=m_pBufDC;
	pUI->m_hWnd=m_hWnd;
	pUI->m_X1+=m_X1;
	pUI->m_Y1+=m_Y1;
	pUI->m_X2=pUI->m_X1+pUI->m_Width;
	pUI->m_Y2=pUI->m_Y1+pUI->m_Height;
	m_nChild++;
}

void SBoard::Draw()
{
	Graphics canvas(m_pBufDC->GetSafeHdc());
	canvas.DrawImage(p_Images[m_Image],m_X1,m_Y1,m_Width,m_Height);
	for(int i=0;i<m_nChild;i++)
	{
		m_Children[i].pChild->Draw();
	}
}

void SBoard::OnLDown(int x,int y)
{
	SummerUI::OnLDown(x,y);
	for(int i=0;i<m_nChild;i++)
		if(m_Children[i].pChild->InArea(x,y))
			m_Children[i].pChild->OnLDown(x,y);
	m_MouseDown=true;
	m_DownMX=x;
	m_DownMY=y;
	m_DownX=m_X1;
	m_DownY=m_Y1;
}

void SBoard::OnLUp(int x,int y)
{		
	m_MouseDown=false;
	for(int i=0;i<m_nChild;i++)
		m_Children[i].pChild->OnLUp(x,y);
}

void SBoard::OnRDown(int x,int y)
{
	SummerUI::OnRDown(x,y);
}

void SBoard::OnMouseMove(int x,int y)
{
		for(int i=0;i<m_nChild;i++)
		    m_Children[i].pChild->OnMouseMove(x,y);
		if(InArea(x,y))
			if(m_OnMouseMove)
				m_OnMouseMove(x,y);
		if(m_MouseDown)
		{
			int dx=x-m_DownMX;
			int dy=y-m_DownMY;
			m_X1=m_DownX+dx;
			m_Y1=m_DownY+dy;
			m_X2=m_X1+m_Width;
			m_Y2=m_Y1+m_Height;
			for(int i=0;i<m_nChild;i++)
			{
				m_Children[i].pChild->m_X1=m_Children[i].rx+m_X1;
				m_Children[i].pChild->m_Y1=m_Children[i].ry+m_Y1;
				m_Children[i].pChild->m_X2=m_Children[i].pChild->m_X1+m_Children[i].pChild->m_Width-1;
				m_Children[i].pChild->m_Y2=m_Children[i].pChild->m_Y1+m_Children[i].pChild->m_Height-1;
			}
		    InvalidateRect(m_hWnd,NULL,FALSE);//�ƶ���ʱ��Ӧ�ػ���������
		}
}